declare namespace output = "http://www.w3.org/2010/xslt-xquery-serialization";
declare option output:method "html";
declare option output:indent "yes";

for $x in collection("C:\Hermes_Archives\tickets")/ticket
order by xs:integer($x/alerta_sla/@dias_retraso) descending
return <retraso_ticket>
  <Operador>{data($x/operador/Nombre)}</Operador>
  <dias>{data($x/alerta_sla/@dias_retraso)}</dias>
</retraso_ticket>