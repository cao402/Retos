declare namespace output = "http://www.w3.org/2010/xslt-xquery-serialization";
declare option output:method "html";
declare option output:indent "yes";

for $x in collection("C:\Hermes_Archives\tickets")/ticket
where $x/datos_ticket/Prioridad="Critica" 
return <email>{data($x/cliente/Correo)}</email>