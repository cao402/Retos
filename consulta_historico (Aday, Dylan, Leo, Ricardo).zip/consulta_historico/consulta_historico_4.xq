declare namespace output = "http://www.w3.org/2010/xslt-xquery-serialization";
declare option output:method "html";
declare option output:indent "yes";

for $x in collection("C:\Hermes_Archives\tickets")/ticket
let $num_mensaje := count($x/historial/mensaje)
return <cantidad_mensaje>{data($num_mensaje)}</cantidad_mensaje>